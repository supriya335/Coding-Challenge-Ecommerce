package com.hospital_mngt.main;

import com.hospital_mngt.dao.HospitalServiceImpl;
import com.hospital_mngt.entity.Appointment;
import com.hospital_mngt.exception.PatientNumberNotFoundException;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class MainModule {
    public static void main(String[] args) throws SQLException {
        HospitalServiceImpl service = new HospitalServiceImpl();
        HospitalServiceImpl hospitalService = new HospitalServiceImpl();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n--- Hospital Management Menu ---");
            System.out.println("1. Get Appointment by ID");
            System.out.println("2. Get Appointments for Patient");
            System.out.println("3. Get Appointments for Doctor");
            System.out.println("4. Schedule Appointment");
            System.out.println("5. Update Appointment");
            System.out.println("6. Cancel Appointment");
            System.out.println("7. Exit");
            System.out.println("\nEnter any choice");
            int choice = sc.nextInt();

            switch (choice) {

                case 1:
                    System.out.print("Enter appointment ID: ");
                    Appointment appt = service.getAppointmentById(sc.nextInt());
                    System.out.println(appt);
                    break;
                case 2:
                    System.out.print("Enter patient ID: ");
                    int patientId = sc.nextInt();
                    try {
                        List<Appointment> plist = service.getAppointmentsForPatient(patientId);

                        if (plist.isEmpty()) {
                            throw new PatientNumberNotFoundException("No appointments found for patient ID: " + patientId);
                        }

                        plist.forEach(System.out::println);
                    } catch (PatientNumberNotFoundException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 3:
                    System.out.print("Enter doctor ID: ");
                    List<Appointment> dlist = service.getAppointmentsForDoctor(sc.nextInt());
                    dlist.forEach(System.out::println);
                    break;
                case 4:
                    System.out.print("Enter all appointment details: ");
                    System.out.println("Enter appointed_id, patient_id, doctor_id, date, Reason/Issues");
                    Appointment newApt = new Appointment(sc.nextInt(), sc.nextInt(), sc.nextInt(), sc.next(), sc.next());
                    System.out.println(service.scheduleAppointment(newApt) ? "Scheduled" : "Failed");
                    break;
                case 5:
                    System.out.print("Enter updated appointment details: ");
                    Appointment upApt = new Appointment(sc.nextInt(), sc.nextInt(), sc.nextInt(), sc.next(), sc.next());
                    System.out.println(service.updateAppointment(upApt) ? "Updated" : "Failed");
                    break;


                case 6:
                    System.out.print("Enter appointment ID: ");
                    System.out.println(service.cancelAppointment(sc.nextInt()) ? "Cancelled" : "Failed");
                    break;
                case 7:
                    System.out.println("Thank You!");
                    System.exit(0);
            }
        }
    }
}
