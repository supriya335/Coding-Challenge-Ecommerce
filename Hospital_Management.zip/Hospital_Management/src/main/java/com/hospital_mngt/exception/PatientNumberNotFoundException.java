package com.hospital_mngt.exception;

public class PatientNumberNotFoundException extends Exception

{ public PatientNumberNotFoundException(String message) { super(message); } }
