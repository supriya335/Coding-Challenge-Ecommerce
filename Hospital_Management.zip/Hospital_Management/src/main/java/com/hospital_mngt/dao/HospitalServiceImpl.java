package com.hospital_mngt.dao;

import com.hospital_mngt.entity.Appointment;
import com.hospital_mngt.exception.PatientNumberNotFoundException;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class HospitalServiceImpl implements IHospitalService {
    private static final String URL = "jdbc:mysql://localhost:3306/hospital_db";
    private static final String USER = "root";
    private static final String PASSWORD = "Hexaware@12345";

private Connection conn;

public HospitalServiceImpl() throws SQLException {
    this.conn = DriverManager.getConnection(URL, USER, PASSWORD);
}

@Override
public Appointment getAppointmentById(int appointmentId) {
    Appointment appt = null;
    try {
        PreparedStatement stmt = conn.prepareStatement("SELECT * FROM appointment WHERE appointment_id = ?");
        stmt.setInt(1, appointmentId);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            appt = new Appointment(rs.getInt(1), rs.getInt(2), rs.getInt(3), rs.getString(4), rs.getString(5));
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return appt;
}

@Override
public List<Appointment> getAppointmentsForPatient(int patientId) {
    List<Appointment> list = new ArrayList<>();
    try {
        PreparedStatement stmt = conn.prepareStatement("SELECT * FROM appointment WHERE patient_id= ?");
        stmt.setInt(1, patientId);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            list.add(new Appointment(rs.getInt(1), rs.getInt(2), rs.getInt(3), rs.getString(4), rs.getString(5)));
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return list;
}

@Override
public List<Appointment> getAppointmentsForDoctor(int doctorId) {
    List<Appointment> list = new ArrayList<>();
    try {
        PreparedStatement stmt = conn.prepareStatement("SELECT * FROM appointment WHERE doctor_id = ?");
        stmt.setInt(1, doctorId);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            list.add(new Appointment(rs.getInt(1), rs.getInt(2), rs.getInt(3), rs.getString(4), rs.getString(5)));
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return list;
}



    @Override
public boolean scheduleAppointment(Appointment appointment) {
    try {
        PreparedStatement stmt = conn.prepareStatement("INSERT INTO appointment VALUES (?, ?, ?, ?, ?)");
        stmt.setInt(1, appointment.getAppointmentId());
        stmt.setInt(2, appointment.getPatientId());
        stmt.setInt(3, appointment.getDoctorId());
        stmt.setString(4, appointment.getAppointmentDate());
        stmt.setString(5, appointment.getDescription());
        return stmt.executeUpdate() > 0;
    } catch (Exception e) {
        e.printStackTrace();
    }
    return false;
}

//@Override
//public boolean updateAppointment(Appointment appointment) {
//    try {
//        PreparedStatement stmt = conn.prepareStatement("UPDATE appointment SET patient_id=?, doctor_id=?, appointment_date=?, description=? WHERE appointment_id=?");
//        stmt.setInt(1, appointment.getPatientId());
//        stmt.setInt(2, appointment.getDoctorId());
//        stmt.setString(3, appointment.getAppointmentDate());
//        stmt.setString(4, appointment.getDescription());
//        stmt.setInt(5, appointment.getAppointmentId());
//        return stmt.executeUpdate() > 0;
//    } catch (Exception e) {
//        e.printStackTrace();
//    }
//    return false;
//}
@Override
public boolean updateAppointment(Appointment appointment) {
    try {
        PreparedStatement stmt = conn.prepareStatement("UPDATE appointment SET patient_id=?, doctor_id=?, appointment_date=?, description=? WHERE appointment_id=?");
        stmt.setInt(1, appointment.getPatientId());
        stmt.setInt(2, appointment.getDoctorId());
        stmt.setString(3, appointment.getAppointmentDate());
        stmt.setString(4, appointment.getDescription());
        stmt.setInt(5, appointment.getAppointmentId());
        return stmt.executeUpdate() > 0;
    } catch (Exception e) {
        e.printStackTrace();
    }
    return false;
}
@Override
public boolean cancelAppointment(int appointmentId) {
    try {
        PreparedStatement stmt = conn.prepareStatement("DELETE FROM appointment WHERE appointment_id = ?");
        stmt.setInt(1, appointmentId);
        return stmt.executeUpdate() > 0;
    } catch (Exception e) {
        e.printStackTrace();
    }
    return false;
}

}


/*package dao;

import entity.Artwork;
import myexceptions.ArtWorkNotFoundException;
import myexceptions.UserNotFoundException;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class VirtualArtGalleryImpl implements IVirtualArtGallery {

    private static final String URL = "jdbc:mysql://localhost:3306/Virtual_Art_Gallery";
    private static final String USER = "root";
    private static final String PASS = "Hexaware@12345";

    @Override
    public boolean addArtwork(Artwork artwork) {
        String insertArtwork = "INSERT INTO Artwork (Title, Description, CreationDate, Medium, ImageURL, ArtistID) VALUES (?, ?, ?, ?, ?, ?)";
        String insertArtGallery = "INSERT INTO Artwork_Gallery (ArtworkID, GalleryID) VALUES (?, ?)";

        try (Connection con = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement pst1 = con.prepareStatement(insertArtwork, Statement.RETURN_GENERATED_KEYS);
             PreparedStatement pst2 = con.prepareStatement(insertArtGallery)) {

            pst1.setString(1, artwork.getTitle());
            pst1.setString(2, artwork.getDescription());
            pst1.setDate(3, Date.valueOf(artwork.getCreationDate()));
            pst1.setString(4, artwork.getMedium());
            pst1.setString(5, artwork.getImageUrl());
            pst1.setInt(6, artwork.getArtistId());

            int rows = pst1.executeUpdate();
            if (rows == 0) return false;

            ResultSet generatedKeys = pst1.getGeneratedKeys();
            if (generatedKeys.next()) {
                int artworkId = generatedKeys.getInt(1);
                pst2.setInt(1, artworkId);
                pst2.setInt(2, artwork.getGalleryId());
                pst2.executeUpdate();
                return true;
            }
        } catch (SQLException e) {
            System.out.println("DB Error: " + e.getMessage());
        }
        return false;
    }

    @Override
    public Artwork getArtworkById(int id) throws ArtWorkNotFoundException {
        String query =
                "SELECT a.ArtworkID, a.Title, a.Description, a.CreationDate, a.Medium, a.ImageURL, " +
                        "ar.Name AS ArtistName, g.Name AS GalleryName, g.Location " +
                        "FROM Artwork a " +
                        "JOIN Artist ar ON a.ArtistID = ar.ArtistID " +
                        "JOIN Artwork_Gallery ag ON a.ArtworkID = ag.ArtworkID " +
                        "JOIN Gallery g ON ag.GalleryID = g.GalleryID " +
                        "WHERE a.ArtworkID = ?";

        try (Connection con = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement pst = con.prepareStatement(query)) {

            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                Artwork a = new Artwork();
                a.setArtworkId(rs.getInt("ArtworkID"));
                a.setTitle(rs.getString("Title"));
                a.setDescription(rs.getString("Description"));
                a.setCreationDate(rs.getString("CreationDate"));
                a.setMedium(rs.getString("Medium"));
                a.setImageUrl(rs.getString("ImageURL"));
                a.setArtistName(rs.getString("ArtistName"));
                a.setGalleryName(rs.getString("GalleryName"));
                a.setGalleryLocation(rs.getString("Location"));
                return a;
            } else {
                throw new ArtWorkNotFoundException("Artwork not found with ID: " + id);
            }
        } catch (SQLException e) {
            throw new ArtWorkNotFoundException("Database error: " + e.getMessage());
        }
    }

    @Override
    public List<Artwork> searchArtworks(String keyword) {
        List<Artwork> artworks = new ArrayList<>();
        String searchQuery = "SELECT ArtworkID, Title FROM Artwork WHERE Title LIKE ? OR Description LIKE ?";

        try (Connection con = DriverManager.getConnection(URL, USER, PASS);
             PreparedStatement pst = con.prepareStatement(searchQuery)) {

            String pattern = "%" + keyword + "%";
            pst.setString(1, pattern);
            pst.setString(2, pattern);

            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                Artwork a = new Artwork();
                a.setArtworkId(rs.getInt("ArtworkID"));
                a.setTitle(rs.getString("Title"));
                artworks.add(a);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return artworks;
    }

    @Override
    public boolean updateArtwork(int artworkId, Artwork updatedArtwork) throws ArtWorkNotFoundException {
        String checkQuery = "SELECT * FROM Artwork WHERE ArtworkID = ?";
        String updateQuery = "UPDATE Artwork SET Title = ?, Description = ?, CreationDate = ?, Medium = ?, ImageURL = ? WHERE ArtworkID = ?";

        try (Connection con = DriverManager.getConnection(URL, USER, PASS)) {

            // Step 1: Check if the artwork ID exists
            try (PreparedStatement checkStmt = con.prepareStatement(checkQuery)) {
                checkStmt.setInt(1, artworkId);
                ResultSet rs = checkStmt.executeQuery();
                if (!rs.next()) {
                    throw new UserNotFoundException("Artwork with User ID " + artworkId + " not found.");
                }
            }

            // Step 2: Proceed with the update
            try (PreparedStatement updateStmt = con.prepareStatement(updateQuery)) {
                updateStmt.setString(1, updatedArtwork.getTitle());
                updateStmt.setString(2, updatedArtwork.getDescription());
                updateStmt.setDate(3, Date.valueOf(updatedArtwork.getCreationDate()));
                updateStmt.setString(4, updatedArtwork.getMedium());
                updateStmt.setString(5, updatedArtwork.getImageUrl());
                updateStmt.setInt(6, artworkId);

                int rows = updateStmt.executeUpdate();
                return rows > 0;
            }

        } catch (SQLException e) {
            System.out.println("Update error: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean deleteArtwork(int artworkId) {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASS)) {

            // 1. Delete from user_favorite_artwork
            String deleteFavorites = "DELETE FROM user_favorite_artwork WHERE ArtworkID = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(deleteFavorites)) {
                pstmt.setInt(1, artworkId);
                pstmt.executeUpdate();
            }

            // 2. Delete from artwork_gallery
            String deleteGallery = "DELETE FROM artwork_gallery WHERE ArtworkID = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(deleteGallery)) {
                pstmt.setInt(1, artworkId);
                pstmt.executeUpdate();
            }

            // 3. Delete from artwork
            String deleteArtwork = "DELETE FROM artwork WHERE ArtworkID = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(deleteArtwork)) {
                pstmt.setInt(1, artworkId);
                int rows = pstmt.executeUpdate();
                return rows > 0;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }



}

*/