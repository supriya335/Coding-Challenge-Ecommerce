package myexceptions;

public class ArtWorkNotFoundException extends RuntimeException {
    public ArtWorkNotFoundException(String message) {
        super(message);
    }
}
