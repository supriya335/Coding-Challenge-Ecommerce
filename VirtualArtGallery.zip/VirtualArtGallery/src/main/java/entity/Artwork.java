//package entity;
//
//public class Artwork {
//    private int artworkId;
//    private String title;
//    private String description;
//    private String creationDate;
//    private String medium;
//    private String imageUrl;
//    private int artistId;
//
//    public Artwork() {}
//
//    public Artwork(int artworkId, String title, String description, String creationDate, String medium, String imageUrl, int artistId) {
//        this.artworkId = artworkId;
//        this.title = title;
//        this.description = description;
//        this.creationDate = creationDate;
//        this.medium = medium;
//        this.imageUrl = imageUrl;
//        this.artistId = artistId;
//    }
//
//    public int getArtworkId() {
//        return artworkId;
//    }
//
//    public void setArtworkId(int artworkId) {
//        this.artworkId = artworkId;
//    }
//
//    public String getTitle() {
//        return title;
//    }
//
//    public void setTitle(String title) {
//        this.title = title;
//    }
//
//    public String getDescription() {
//        return description;
//    }
//
//    public void setDescription(String description) {
//        this.description = description;
//    }
//
//    public String getCreationDate() {
//        return creationDate;
//    }
//
//    public void setCreationDate(String creationDate) {
//        this.creationDate = creationDate;
//    }
//
//    public String getMedium() {
//        return medium;
//    }
//
//    public void setMedium(String medium) {
//        this.medium = medium;
//    }
//
//    public String getImageUrl() {
//        return imageUrl;
//    }
//
//    public void setImageUrl(String imageUrl) {
//        this.imageUrl = imageUrl;
//    }
//
//    public int getArtistId() {
//        return artistId;
//    }
//
//    public void setArtistId(int artistId) {
//        this.artistId = artistId;
//    }
//}

package entity;

public class Artwork {
    private int artworkId;
    private String title;
    private String description;
    private String creationDate;
    private String medium;
    private String imageUrl;
    private int artistId;
    private int galleryId;

    // Additional joined fields
    private String artistName;
    private String galleryName;
    private String galleryLocation;

    // Getters and Setters
    public int getArtworkId() {
        return artworkId;
    }

    public void setArtworkId(int artworkId) {
        this.artworkId = artworkId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(String creationDate) {
        this.creationDate = creationDate;
    }

    public String getMedium() {
        return medium;
    }

    public void setMedium(String medium) {
        this.medium = medium;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public int getArtistId() {
        return artistId;
    }

    public void setArtistId(int artistId) {
        this.artistId = artistId;
    }

    public int getGalleryId() {
        return galleryId;
    }

    public void setGalleryId(int galleryId) {
        this.galleryId = galleryId;
    }

    public String getArtistName() {
        return artistName;
    }

    public void setArtistName(String artistName) {
        this.artistName = artistName;
    }

    public String getGalleryName() {
        return galleryName;
    }

    public void setGalleryName(String galleryName) {
        this.galleryName = galleryName;
    }

    public String getGalleryLocation() {
        return galleryLocation;
    }

    public void setGalleryLocation(String galleryLocation) {
        this.galleryLocation = galleryLocation;
    }
}
