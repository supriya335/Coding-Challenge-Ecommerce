package dao;

import entity.Artwork;
import myexceptions.UserNotFoundException;

import java.util.List;

public interface IVirtualArtGallery {
    boolean addArtwork(Artwork artwork);

    Artwork getArtworkById(int id);

    List<Artwork> searchArtworks(String keyword);

    boolean updateArtwork(int artworkId, Artwork updatedArtwork) throws UserNotFoundException;

    boolean deleteArtwork(int artworkId);
}