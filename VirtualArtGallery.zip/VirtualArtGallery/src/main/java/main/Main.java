package main;

import dao.VirtualArtGalleryImpl;
import entity.Artwork;
import myexceptions.ArtWorkNotFoundException;
import myexceptions.UserNotFoundException;

import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        VirtualArtGalleryImpl gallery = new VirtualArtGalleryImpl();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n🎨 Virtual Art Gallery Menu 🎨");
            System.out.println("1. Add Artwork");
            System.out.println("2. Get Artwork by ID");
            System.out.println("3. Search Artworks by Keyword");
            System.out.println("4. Update Artwork");
            System.out.println("5. Delete Artwork");
            System.out.println("6. Exit");
            System.out.print("Enter choice: ");
            int choice = sc.nextInt();
            sc.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    Artwork artwork = new Artwork();
                    System.out.print("Enter Title: ");
                    artwork.setTitle(sc.nextLine());
                    System.out.print("Enter Description: ");
                    artwork.setDescription(sc.nextLine());
                    System.out.print("Enter Creation Date (YYYY-MM-DD): ");
                    artwork.setCreationDate(sc.nextLine());
                    System.out.print("Enter Medium: ");
                    artwork.setMedium(sc.nextLine());
                    System.out.print("Enter Image URL: ");
                    artwork.setImageUrl(sc.nextLine());
                    System.out.print("Enter Artist ID: ");
                    artwork.setArtistId(sc.nextInt());
                    System.out.print("Enter Gallery ID: ");
                    artwork.setGalleryId(sc.nextInt());

                    boolean added = gallery.addArtwork(artwork);
                    if (added) {
                        System.out.println("✅ Artwork added successfully!");
                    } else {
                        System.out.println("❌ Failed to add artwork.");
                    }
                    break;

                case 2:
                    System.out.print("Enter Artwork ID: ");
                    int id = sc.nextInt();
                    try {
                        Artwork art = gallery.getArtworkById(id);
                        System.out.println("\n🎨 Artwork Details:");
                        System.out.println("ID: " + art.getArtworkId());
                        System.out.println("Title: " + art.getTitle());
                        System.out.println("Description: " + art.getDescription());
                        System.out.println("Created On: " + art.getCreationDate());
                        System.out.println("Medium: " + art.getMedium());
                        System.out.println("Image URL: " + art.getImageUrl());
                        System.out.println("Artist Name: " + art.getArtistName());
                        System.out.println("Gallery Name: " + art.getGalleryName());
                        System.out.println("Gallery Location: " + art.getGalleryLocation());
                    } catch (ArtWorkNotFoundException e) {
                        System.out.println("❌ " + e.getMessage());
                    }
                    break;

                case 3:
                    System.out.print("Enter keyword to search: ");
                    String keyword = sc.nextLine();
                    List<Artwork> results = gallery.searchArtworks(keyword);
                    System.out.println("\n🔍 Search Results:");
                    if (results.isEmpty()) {
                        System.out.println("No artworks found.");
                    } else {
                        for (Artwork a : results) {
                            System.out.println("ID: " + a.getArtworkId() + " | Title: " + a.getTitle());
                        }
                    }
                    break;

                case 4:
                    System.out.print("Enter Artwork ID to update: ");
                    int updateId = sc.nextInt();
                    sc.nextLine(); // consume newline
                    Artwork updated = new Artwork();
                    try {
                        boolean isUpdated = gallery.updateArtwork(updateId, updated);
                        if (isUpdated) {
                            System.out.println("✅ Artwork updated successfully!");
                        } else {
                            System.out.println("❌ Failed to update artwork.");
                        }
                    } catch (UserNotFoundException e) {
                        System.out.println("🚫 " + e.getMessage());
                        break;
                    }

                    System.out.print("Enter New Title: ");
                    updated.setTitle(sc.nextLine());
                    System.out.print("Enter New Description: ");
                    updated.setDescription(sc.nextLine());
                    System.out.print("Enter New Creation Date (YYYY-MM-DD): ");
                    updated.setCreationDate(sc.nextLine());
                    System.out.print("Enter New Medium: ");
                    updated.setMedium(sc.nextLine());
                    System.out.print("Enter New Image URL: ");
                    updated.setImageUrl(sc.nextLine());


                    break;

                case 5:
                    System.out.print("Enter Artwork ID to delete: ");
                    int deleteId = sc.nextInt();
                    boolean isDeleted = gallery.deleteArtwork(deleteId);
                    if (isDeleted) {
                        System.out.println("🗑️ Artwork deleted successfully!");
                    } else {
                        System.out.println("❌ Failed to delete artwork.");
                    }
                    break;



                case 6:
                    System.out.println("Exiting... 🎭 Have a colorful day!");
                    sc.close();
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid choice, try again.");
            }
        }
    }
}
