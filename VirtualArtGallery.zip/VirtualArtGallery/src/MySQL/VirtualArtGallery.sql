CREATE DATABASE Virtual_Art_Gallery;
use Virtual_Art_Gallery;

CREATE TABLE Artwork (
    ArtworkID INT PRIMARY KEY AUTO_INCREMENT,
    Title VARCHAR(255) NOT NULL,
    Description TEXT,
    CreationDate DATE,
    Medium VARCHAR(100),
    ImageURL VARCHAR(255),
    ArtistID INT,
    FOREIGN KEY (ArtistID) REFERENCES Artist(ArtistID)
);

select * from artwork;

CREATE TABLE Artist (
    ArtistID INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(255) NOT NULL,
    Biography TEXT,
    BirthDate DATE,
    Nationality VARCHAR(100),
    Website VARCHAR(255),
    ContactInformation VARCHAR(255)
);


CREATE TABLE User (
    UserID INT PRIMARY KEY AUTO_INCREMENT,
    Username VARCHAR(100) UNIQUE NOT NULL,
    Password VARCHAR(100) NOT NULL,
    Email VARCHAR(100) UNIQUE NOT NULL,
    FirstName VARCHAR(100),
    LastName VARCHAR(100),
    DateOfBirth DATE,
    ProfilePicture VARCHAR(255)
);


CREATE TABLE Gallery (
    GalleryID INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(255) NOT NULL,
    Description TEXT,
    Location VARCHAR(255),
    Curator INT,
    OpeningHours VARCHAR(100),
    FOREIGN KEY (Curator) REFERENCES Artist(ArtistID)
);

CREATE TABLE User_Favorite_Artwork (
    UserID INT,
    ArtworkID INT,
    PRIMARY KEY (UserID, ArtworkID),
    FOREIGN KEY (UserID) REFERENCES User(UserID),
    FOREIGN KEY (ArtworkID) REFERENCES Artwork(ArtworkID)
);


CREATE TABLE Artwork_Gallery (
    ArtworkID INT,
    GalleryID INT,
    PRIMARY KEY (ArtworkID, GalleryID),
    FOREIGN KEY (ArtworkID) REFERENCES Artwork(ArtworkID),
    FOREIGN KEY (GalleryID) REFERENCES Gallery(GalleryID)
);


INSERT INTO Artist (Name, Biography, BirthDate, Nationality, Website, ContactInformation) VALUES
('Vincent van Gogh', 'Dutch post-impressionist painter.', '1853-03-30', 'Dutch', 'https://vangogh.com', 'vangogh@example.com'),
('Leonardo da Vinci', 'Renaissance genius and artist.', '1452-04-15', 'Italian', 'https://davinci.com', 'davinci@example.com'),
('Frida Kahlo', 'Mexican painter known for self-portraits.', '1907-07-06', 'Mexican', 'https://kahlo.com', 'frida@example.com'),
('Pablo Picasso', 'Spanish painter and sculptor.', '1881-10-25', 'Spanish', 'https://picasso.com', 'picasso@example.com'),
('Claude Monet', 'Founder of French Impressionism.', '1840-11-14', 'French', 'https://monet.com', 'monet@example.com'),
('Andy Warhol', 'Leading figure in pop art.', '1928-08-06', 'American', 'https://warhol.com', 'warhol@example.com'),
('Georgia O’Keeffe', 'Mother of American modernism.', '1887-11-15', 'American', 'https://okeeffe.com', 'okeeffe@example.com'),
('Michelangelo', 'Sculptor, painter, architect.', '1475-03-06', 'Italian', 'https://michelangelo.com', 'mike@example.com'),
('Banksy', 'Anonymous England-based street artist.', NULL, 'British', 'https://banksy.com', 'banksy@example.com'),
('Raja Ravi Varma', 'Indian painter and artist.', '1848-04-29', 'Indian', 'https://ravivarma.com', 'varma@example.com');


INSERT INTO User (Username, Password, Email, FirstName, LastName, DateOfBirth, ProfilePicture) VALUES
('artlover01', 'pass123', 'a1@example.com', 'Ava', 'Smith', '1995-06-12', 'ava.jpg'),
('artistFan2', 'art234', 'a2@example.com', 'Liam', 'Brown', '1993-04-23', 'liam.jpg'),
('galleryQueen', 'gq456', 'a3@example.com', 'Sophia', 'Clark', '2000-11-03', 'sophia.png'),
('modernArtFan', 'mod789', 'a4@example.com', 'Noah', 'Lee', '1990-02-18', 'noah.png'),
('historyNerd', 'hist321', 'a5@example.com', 'Emma', 'Walker', '1998-07-25', 'emma.png'),
('boldBrushes', 'bb111', 'a6@example.com', 'James', 'Taylor', '1997-01-14', 'james.jpg'),
('artHuntress', 'ah654', 'a7@example.com', 'Mia', 'Harris', '1996-12-05', 'mia.jpg'),
('paintObsessed', 'po321', 'a8@example.com', 'Lucas', 'Young', '1994-10-30', 'lucas.jpg'),
('vintageSoul', 'vs555', 'a9@example.com', 'Isabella', 'Hall', '2002-03-17', 'bella.jpg'),
('pixelsNpastels', 'pp888', 'a10@example.com', 'Elijah', 'Allen', '1992-08-20', 'elijah.jpg');


INSERT INTO Gallery (Name, Description, Location, Curator, OpeningHours) VALUES
('Classic Visions', 'A collection of timeless classics.', 'New York', 1, '10:00-18:00'),
('Renaissance Room', 'Dedicated to renaissance art.', 'Florence', 2, '09:00-17:00'),
('Frida’s Dream', 'Mexican color and identity.', 'Mexico City', 3, '10:00-19:00'),
('Cubist Paradise', 'Home to Picasso works.', 'Barcelona', 4, '11:00-20:00'),
('Water Lilies Space', 'Impressionist showcase.', 'Paris', 5, '08:00-16:00'),
('Pop Art Studio', 'American modern pop art.', 'Los Angeles', 6, '12:00-21:00'),
('Modernism Garden', 'Abstract and floral.', 'New Mexico', 7, '09:30-17:30'),
('Divine Marble Hall', 'Renaissance sculptures.', 'Rome', 8, '10:00-18:00'),
('Urban Voice', 'Street art and modern rebellion.', 'London', 9, '11:00-22:00'),
('Indian Heritage', 'Traditional Indian masterpieces.', 'Kerala', 10, '09:00-19:00');


INSERT INTO Artwork (Title, Description, CreationDate, Medium, ImageURL, ArtistID) VALUES
('Starry Night', 'Van Gogh’s swirling masterpiece.', '1889-06-01', 'Oil on canvas', 'starry.jpg', 1),
('Mona Lisa', 'Iconic portrait of Lisa Gherardini.', '1503-01-01', 'Oil', 'mona.jpg', 2),
('The Two Fridas', 'Dual self-portrait by Frida.', '1939-01-01', 'Oil on canvas', 'fridas.jpg', 3),
('Guernica', 'Picasso’s war protest painting.', '1937-04-26', 'Oil on canvas', 'guernica.jpg', 4),
('Water Lilies', 'Tranquil garden scenes.', '1906-01-01', 'Oil on canvas', 'lilies.jpg', 5),
('Marilyn Diptych', 'Warhol’s pop culture work.', '1962-01-01', 'Silkscreen', 'marilyn.jpg', 6),
('Red Canna', 'Vivid flower abstraction.', '1924-01-01', 'Oil on canvas', 'redcanna.jpg', 7),
('Creation of Adam', 'Sistine Chapel masterpiece.', '1512-01-01', 'Fresco', 'adam.jpg', 8),
('Girl with Balloon', 'Banksy’s anonymous art.', '2002-01-01', 'Spray paint', 'balloon.jpg', 9),
('Shakuntala', 'Indian mythological painting.', '1898-01-01', 'Oil on canvas', 'shakuntala.jpg', 10);


INSERT INTO User_Favorite_Artwork (UserID, ArtworkID) VALUES
(1, 1), (1, 2),
(2, 3), (2, 4),
(3, 5), (3, 1),
(4, 6), (5, 7),
(6, 8), (7, 9);


INSERT INTO Artwork_Gallery (ArtworkID, GalleryID) VALUES
(1, 1), (1, 3),
(2, 2), (3, 3),
(4, 4), (5, 5),
(6, 6), (7, 7),
(8, 8), (9, 9),
(10, 10);

select * from artwork;
select * from artist;

