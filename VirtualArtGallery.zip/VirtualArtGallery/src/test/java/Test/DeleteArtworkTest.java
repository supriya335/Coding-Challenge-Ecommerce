package Test;

import dao.VirtualArtGalleryImpl;
import entity.Artwork;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class DeleteArtworkTest {
    @Test
    public void testDeleteArtwork(){
        VirtualArtGalleryImpl gallery = new VirtualArtGalleryImpl();
        int artworkID = 2;
        boolean result = gallery.deleteArtwork(artworkID);
        assertTrue(result, "Artwork deletion failed");

    }
}
