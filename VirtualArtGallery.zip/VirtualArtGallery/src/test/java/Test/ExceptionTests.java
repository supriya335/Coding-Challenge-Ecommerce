package Test;

import dao.VirtualArtGalleryImpl;
import entity.Artwork;
import myexceptions.ArtWorkNotFoundException;
import myexceptions.UserNotFoundException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ExceptionTests {
    @Test
    public void testUpdateNonExistentArtworkThrowsException() {
        VirtualArtGalleryImpl gallery = new VirtualArtGalleryImpl();
        Artwork updated = new Artwork();
        updated.setTitle("Invalid");
        assertThrows(UserNotFoundException.class, () -> gallery.updateArtwork(999, updated));
    }

    @Test
    public void testGetNonExistentArtworkThrowsException() {
        VirtualArtGalleryImpl gallery = new VirtualArtGalleryImpl();
        assertThrows(ArtWorkNotFoundException.class, () -> gallery.getArtworkById(999));
    }
}
