package Test;

import dao.VirtualArtGalleryImpl;
import entity.Artwork;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class SearchArtworkTest {
    private VirtualArtGalleryImpl gallery;

    @BeforeEach
    public void setup() {
        gallery = new VirtualArtGalleryImpl();

        Artwork art1 = new Artwork();
        art1.setTitle("Sunflowers");
        art1.setDescription("By Vincent van Gogh");
        art1.setCreationDate("1888-01-01");
        art1.setMedium("Oil");
        art1.setImageUrl("sunflowers.jpg");
        art1.setArtistId(6);

        Artwork art2 = new Artwork();
        art2.setTitle("Sunset Over Venice");
        art2.setDescription("By Claude Monet");
        art2.setCreationDate("1908-01-01");
        art2.setMedium("Oil");
        art2.setImageUrl("sunset.jpg");
        art2.setArtistId(7);

        gallery.addArtwork(art1);
        gallery.addArtwork(art2);
    }

    @Test
    public void testSearchArtworks() {
        List<Artwork> results = gallery.searchArtworks("sun");
        assertEquals(2, results.size()); // Should match both artworks
    }
}
