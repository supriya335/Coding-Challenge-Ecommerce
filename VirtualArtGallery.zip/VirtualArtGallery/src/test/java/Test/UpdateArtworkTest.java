package Test;


import dao.VirtualArtGalleryImpl;
import entity.Artwork;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
public class UpdateArtworkTest {
    @Test
    public void testDeleteArtwork() {
        VirtualArtGalleryImpl gallery = new VirtualArtGalleryImpl();
        Artwork updatedArt = new Artwork();
        updatedArt.setArtworkId(1);
        updatedArt.setTitle("Starry Night");
        updatedArt.setDescription("Van Gogh’s swirling masterpiece.");
        updatedArt.setArtistId(1);
        updatedArt.setCreationDate("2000-03-09");

        assertTrue(gallery.updateArtwork(6,updatedArt));
    }
}