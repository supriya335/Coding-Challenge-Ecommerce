package Test;

import dao.VirtualArtGalleryImpl;
import entity.Artwork;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class AddArtworkTest {
    @Test
    public void testAddArtwork() {
        VirtualArtGalleryImpl gallery = new VirtualArtGalleryImpl();

        Artwork art = new Artwork();
        art.setTitle("Test Art");
        art.setDescription("Just testing");
        art.setCreationDate("2020-01-01");
        art.setMedium("Test Medium");
        art.setImageUrl("test.jpg");
        art.setArtistId(1);
        art.setGalleryId(1);

        assertTrue(gallery.addArtwork(art));
    }
}
