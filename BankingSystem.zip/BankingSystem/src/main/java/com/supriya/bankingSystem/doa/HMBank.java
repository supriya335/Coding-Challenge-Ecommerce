package com.supriya.bankingSystem.doa;

import com.supriya.bankingSystem.entity.*;
import com.supriya.bankingSystem.exception.*;

import java.util.*;

public class HMBank {
    private Map<Long, BankAccount> accounts;

    public HMBank() {
        accounts = new HashMap<>();
    }

    public void addAccount(BankAccount account) {
        if (!accounts.containsKey(account.getAccountNumber())) {
            accounts.put(account.getAccountNumber(), account);
        }
    }

    public BankAccount getAccount(long accountNumber) throws InvalidAccountException {
        BankAccount acc = accounts.get(accountNumber);
        if (acc == null) {
            throw new InvalidAccountException("Account not found: " + accountNumber);
        }
        return acc;
    }

    public void deposit(long accountNumber, float amount) throws InvalidAccountException {
        BankAccount acc = getAccount(accountNumber);
        acc.deposit(amount);
    }

    public void withdraw(long accountNumber, float amount)
            throws Exception{
        BankAccount acc = getAccount(accountNumber);
        acc.withdraw(amount);
    }

    public void transferAmount(long fromAcc, long toAcc, float amount)
            throws Exception {

        BankAccount source = getAccount(fromAcc);
        BankAccount target = getAccount(toAcc);

        if (source.getBalance() < amount) {
            throw new InsufficientFundException("Insufficient funds for transfer.");
        }

        source.withdraw(amount);
        target.deposit(amount);
    }

    public void listAccounts() {
        List<BankAccount> sorted = new ArrayList<>(accounts.values());
        sorted.sort(Comparator.comparing(BankAccount::getCustomerName));
        for (BankAccount acc : sorted) {
            acc.printAccountDetails();
            System.out.println("---");
        }
    }
}
