package com.supriya.bankingSystem.main;

import java.util.Scanner;

public class CompoundInterestCalculator {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter number of customers: ");
        int numCustomers = sc.nextInt();

        for (int i = 1; i <= numCustomers; i++) {
            System.out.println("\nCustomer " + i + ":");
            System.out.print("Enter initial balance: ");
            double principal = sc.nextDouble();

            System.out.print("Enter annual interest rate (in %): ");
            double rate = sc.nextDouble();

            System.out.print("Enter number of years: ");
            int years = sc.nextInt();

            double futureBalance = principal * Math.pow((1 + rate / 100), years);
            System.out.printf("Future balance after %d years: ₹%.2f\n", years, futureBalance);
        }

        sc.close();
    }
}
