package com.supriya.bankingSystem.doa;

import com.supriya.bankingSystem.entity.Customer;
import com.supriya.bankingSystem.exception.LoanNotEligibleException;

public class LoanServiceImpl implements LoanService {
    @Override
    public boolean isEligibleForLoan(Customer customer) throws LoanNotEligibleException {
        if (customer.getCreditScore() > 700 && customer.getAnnualIncome() >= 50000) {
            return true;
        } else {
            throw new LoanNotEligibleException("Credit Score must be above 700 and income at least $50,000");
        }
    }
}