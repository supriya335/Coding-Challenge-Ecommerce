package com.supriya.bankingSystem.doa;

import com.supriya.bankingSystem.entity.AccountDetails;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BankDAO {

    private static final String URL = "jdbc:mysql://localhost:3306/HMBank4";
    private static final String USER = "root";
    private static final String PASSWORD = "Hexaware@12345"; // replace with your actual password

    // Create
    public void addAccount(AccountDetails acc) throws SQLException {
        String query = "INSERT INTO Accounts (customer_id, account_type, balance) VALUES (?, ?, ?)";
        try (Connection con = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pst = con.prepareStatement(query)) {
            pst.setLong(1, acc.getAccountNumber());
            pst.setString(2, acc.getCustomerName());
            pst.setFloat(3, acc.getBalance());
            pst.executeUpdate();
        }
    }

    // Read (Single Account)
    public AccountDetails getAccount(long accNo) throws SQLException {
        String query = "SELECT * FROM Accounts WHERE account_id = ?";
        try (Connection con = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pst = con.prepareStatement(query)) {
            pst.setLong(1, accNo);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                return new AccountDetails(
                        rs.getLong("account_id"),
                        rs.getString("account_type"),
                        rs.getFloat("balance")
                );
            }
        }
        return null;
    }

    // Read (All Accounts)
    public List<AccountDetails> getAllAccounts() throws SQLException {
        List<AccountDetails> list = new ArrayList<>();
        String query = "SELECT * FROM Accounts";
        try (Connection con = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = con.createStatement()) {
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                AccountDetails acc = new AccountDetails(
                        rs.getLong("account_id"),
                        rs.getString("account_type"),
                        rs.getFloat("balance")
                );
                list.add(acc);
            }
        }
        return list;
    }

    // Update
    public void updateAccount(AccountDetails acc) throws SQLException {
        String query = "UPDATE Accounts SET customer_id = ?, balance = ? WHERE account_id = ?";
        try (Connection con = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pst = con.prepareStatement(query)) {
            pst.setString(1, acc.getCustomerName());
            pst.setFloat(2, acc.getBalance());
            pst.setLong(3, acc.getAccountNumber());
            pst.executeUpdate();
        }
    }

    // Delete
    public void deleteAccount(long accNo) throws SQLException {
        String query = "DELETE FROM Accounts WHERE account_id = ?";
        try (Connection con = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pst = con.prepareStatement(query)) {
            pst.setLong(1, accNo);
            pst.executeUpdate();
        }
    }
}
