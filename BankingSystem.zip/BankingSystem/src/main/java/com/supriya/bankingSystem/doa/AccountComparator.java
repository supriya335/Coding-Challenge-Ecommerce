package com.supriya.bankingSystem.doa;

import com.supriya.bankingSystem.entity.BankAccount;

import java.util.Comparator;

public class AccountComparator implements Comparator<BankAccount> {
    public int compare(BankAccount a1, BankAccount a2) {
        return a1.getCustomerName().compareToIgnoreCase(a2.getCustomerName());
    }
}
