package com.supriya.bankingSystem.entity;

public class Account {
    private String accountNumber;
    private String accountType;
    private double balance;
    //starts 14 task
    protected int accountId;
    protected Customer customer;
    protected static int lastAccNo = 1000;
//end
    public Account() {}

    public Account(String accountNumber, String accountType, double balance) {
        this.accountNumber = accountNumber;
        this.accountType = accountType;
        this.balance = balance;
    }

    public String getAccountNumber() { return accountNumber; }
    public String getAccountType() { return accountType; }

    // Protected for subclasses
    protected double getBalance() { return balance; }
    protected void setBalance(double balance) { this.balance = balance; }

    public void setAccountNumber(String accountNumber) { this.accountNumber = accountNumber; }
    public void setAccountType(String accountType) { this.accountType = accountType; }

    // Overloaded deposit methods
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposited ₹" + amount);
        } else {
            System.out.println("Invalid deposit amount.");
        }
    }

    public void deposit(float amount) {
        deposit((double) amount);
    }

    public void deposit(int amount) {
        deposit((double) amount);
    }

    // Overloaded withdraw methods
    public void withdraw(double amount) {
        if (amount <= 0) {
            System.out.println("Invalid withdrawal amount.");
        } else if (amount > balance) {
            System.out.println("Insufficient balance.");
        } else {
            balance -= amount;
            System.out.println("Withdrew ₹" + amount);
        }
    }

    public void withdraw(float amount) {
        withdraw((double) amount);
    }

    public void withdraw(int amount) {
        withdraw((double) amount);
    }

    public void calculateInterest() {
        double interestRate = 4.5;
        double interest = (balance * interestRate) / 100;
        balance += interest;
        System.out.println("Interest of ₹" + interest + " added to account.");
    }

    public void printAccountInfo() {
        System.out.println("Account No   : " + accountNumber);
        System.out.println("Account Type : " + accountType);
        System.out.println("Balance      : ₹" + balance);
    }
}
