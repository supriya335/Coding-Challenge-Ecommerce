package com.supriya.bankingSystem.entity;

import com.supriya.bankingSystem.exception.OverDraftLimitExceededException;

public class CurrentAccount extends BankAccount {

    public CurrentAccount(long accountNumber, String customerName, float balance) {
        super(accountNumber, customerName, balance);
    }

    @Override
    public void deposit(float amount) {
        balance += amount;
        System.out.println("Deposited. New balance: ₹" + balance);
    }

    @Override
    public void withdraw(float amount) throws OverDraftLimitExceededException {
        if (amount <= balance) {
            balance -= amount;
            System.out.println("Withdrawn. New balance: ₹" + balance);
        } else {
            throw new OverDraftLimitExceededException("Overdraft limit exceeded!");
        }
    }

    @Override
    public void calculateInterest() {
        System.out.println("No interest for Current Account.");
    }
}
