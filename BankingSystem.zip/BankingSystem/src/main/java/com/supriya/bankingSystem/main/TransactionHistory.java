package com.supriya.bankingSystem.main;

import java.util.ArrayList;
import java.util.Scanner;

public class TransactionHistory {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<String> transactions = new ArrayList<>();
        double balance = 0.0;

        while (true) {
            System.out.println("\nChoose an option:\n1. Deposit\n2. Withdraw\n3. Exit");
            int choice = sc.nextInt();

            if (choice == 1) {
                System.out.print("Enter deposit amount: ₹");
                double deposit = sc.nextDouble();
                balance += deposit;
                transactions.add("Deposited ₹" + deposit);
            } else if (choice == 2) {
                System.out.print("Enter withdrawal amount: ₹");
                double withdraw = sc.nextDouble();
                if (withdraw <= balance) {
                    balance -= withdraw;
                    transactions.add("Withdrew ₹" + withdraw);
                } else {
                    System.out.println("Insufficient balance.");
                }
            } else if (choice == 3) {
                break;
            } else {
                System.out.println("Invalid option. Try again.");
            }
        }

        System.out.println("\nTransaction History:");
        for (String txn : transactions) {
            System.out.println("- " + txn);
        }

        System.out.printf("Final Balance: ₹%.2f\n", balance);
        sc.close();
    }
}
