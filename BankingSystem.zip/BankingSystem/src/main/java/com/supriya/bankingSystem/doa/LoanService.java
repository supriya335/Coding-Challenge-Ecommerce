package com.supriya.bankingSystem.doa;

import com.supriya.bankingSystem.entity.Customer;
import com.supriya.bankingSystem.exception.LoanNotEligibleException;

public interface LoanService {
    boolean isEligibleForLoan(Customer customer) throws LoanNotEligibleException;
}
