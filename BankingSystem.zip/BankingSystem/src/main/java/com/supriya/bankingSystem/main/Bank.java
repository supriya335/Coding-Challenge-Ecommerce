package com.supriya.bankingSystem.main;

import com.supriya.bankingSystem.doa.HMBank;
import com.supriya.bankingSystem.entity.BankAccount;
import com.supriya.bankingSystem.entity.SavingsAccount;
import com.supriya.bankingSystem.entity.CurrentAccount;
import com.supriya.bankingSystem.exception.*;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Bank {
    public static void main(String[] args) throws Exception{
        Scanner sc = new Scanner(System.in);
        HMBank bank = new HMBank();

        try {


            System.out.print("Enter Customer Name: ");
            String name = sc.nextLine();

            System.out.print("Enter Initial Balance: ");
            float balance = sc.nextFloat();

            long accountNumber = System.currentTimeMillis(); // Unique account number
            BankAccount account = null;

            System.out.println("Choose Account Type:\n 1.Savings Account\n2. Current Account");
            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    System.out.print("Enter Interest Rate: ");
                    float rate = sc.nextFloat();
                    account = new SavingsAccount(accountNumber, name, balance, rate);
                    break;
                case 2:
                    account = new CurrentAccount(accountNumber, name, balance);
                    break;
                default:
                    System.out.println("Invalid account type selected.");
                    return;
            }

            bank.addAccount(account);
            System.out.println("\n✅ Account created successfully!");
            account.printAccountDetails();

            System.out.print("\nEnter amount to deposit: ");
            float depositAmount = sc.nextFloat();
            account.deposit(depositAmount);

            System.out.print("\nEnter amount to withdraw: ");
            float withdrawAmount = sc.nextFloat();

            account.withdraw(withdrawAmount);

            account.calculateInterest();

            // Optional: Transfer test
            System.out.print("\nDo you want to create another account for transfer test? (yes/no): ");
            sc.nextLine(); // Consume newline
            String answer = sc.nextLine();
            if (answer.equalsIgnoreCase("yes")) {
                System.out.print("Enter Customer Name for second account: ");
                String name2 = sc.nextLine();

                System.out.print("Enter Initial Balance: ");
                float balance2 = sc.nextFloat();

                long accountNumber2 = accountNumber + 1;
                BankAccount account2 = new SavingsAccount(accountNumber2, name2, balance2, 5.0f);
                bank.addAccount(account2);

                System.out.print("Enter amount to transfer from first to second account: ");
                float transferAmount = sc.nextFloat();

                bank.transferAmount(account.getAccountNumber(), account2.getAccountNumber(), transferAmount);
            }

        } catch (InvalidAccountException | InsufficientFundException | OverDraftLimitExceededException e) {
            System.out.println("Exception: " + e.getMessage());
        } catch (NullPointerException e) {
            System.out.println("NullPointerException: Some data might be missing.");
        } catch (InputMismatchException e) {
            System.out.println("Please enter valid inputs.");
        } finally {
            sc.close();
        }
    }
}
