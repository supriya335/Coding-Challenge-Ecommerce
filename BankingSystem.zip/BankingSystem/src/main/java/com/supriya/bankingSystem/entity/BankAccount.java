package com.supriya.bankingSystem.entity;

public abstract class BankAccount {
    protected long accountNumber;
    protected String customerName;
    protected float balance;


    // ✅ No-arg constructor
    public BankAccount() {}

    public BankAccount(long accountNumber, String customerName, float balance) {
        this.accountNumber = accountNumber;
        this.customerName = customerName;
        this.balance = balance;
    }

    public long getAccountNumber() {
        return accountNumber;
    }

    public String getCustomerName() {
        return customerName;
    }

    public float getBalance() {
        return balance;
    }

    public abstract void deposit(float amount);

    public abstract void withdraw(float amount)throws Exception;

    public abstract void calculateInterest();

    public void printAccountDetails() {
        System.out.println("\nAccount Number: " + accountNumber);
        System.out.println("Name: " + customerName);
        System.out.println("Balance: ₹" + balance);
    }

    public static class AccountDetails {
        private long accountNumber;
        private String customerName;
        private float balance;

        public AccountDetails(long accountNumber, String customerName, float balance) {
            this.accountNumber = accountNumber;
            this.customerName = customerName;
            this.balance = balance;
        }

        public long getAccountNumber() {
            return accountNumber;
        }

        public String getCustomerName() {
            return customerName;
        }

        public float getBalance() {
            return balance;
        }

        public void setCustomerName(String customerName) {
            this.customerName = customerName;
        }

        public void setBalance(float balance) {
            this.balance = balance;
        }
    }
}
