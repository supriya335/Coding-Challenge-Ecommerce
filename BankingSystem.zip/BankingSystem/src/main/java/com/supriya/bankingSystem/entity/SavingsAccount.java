
package com.supriya.bankingSystem.entity;

public class SavingsAccount extends BankAccount {
    private float interestRate;
    public SavingsAccount() {}

    public SavingsAccount(long accountNumber, String customerName, float balance, float interestRate) {
        super(accountNumber, customerName, balance);
        this.interestRate = interestRate;
    }

    public float getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(float interestRate) {
        this.interestRate = interestRate;
    }

    @Override
    public void deposit(float amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Amount deposited. New balance: ₹" + balance);
        } else {
            System.out.println("Invalid amount.");
        }
    }

    @Override
    public void withdraw(float amount) {
        if (amount > 0 && balance >= amount) {
            balance -= amount;
            System.out.println("Amount withdrawn. New balance: ₹" + balance);
        } else {
            System.out.println("Insufficient balance or invalid amount.");
        }
    }

    @Override
    public void calculateInterest() {
        float interest = balance * interestRate / 100;
        balance += interest;
        System.out.println("Interest added: ₹" + interest + ". New balance: ₹" + balance);
    }
}
