CREATE DATABASE HMBank4;
USE HMBank4;

set sql_safe_updates = 0;
CREATE TABLE Customers (
    customer_id INT PRIMARY KEY AUTO_INCREMENT,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    DOB DATE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone_number VARCHAR(15) UNIQUE NOT NULL,
    address TEXT
);


CREATE TABLE Accounts (
    account_id INT PRIMARY KEY AUTO_INCREMENT,
    customer_id INT NOT NULL,
    account_type ENUM('savings', 'current', 'zero_balance') NOT NULL,
    balance DECIMAL(12, 2) DEFAULT 0.00,
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id) ON DELETE CASCADE
);

CREATE TABLE Transactions (
    transaction_id INT PRIMARY KEY AUTO_INCREMENT,
    account_id INT NOT NULL,
    transaction_type ENUM('deposit', 'withdrawal', 'transfer') NOT NULL,
    amount DECIMAL(12, 2) NOT NULL,
    transaction_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (account_id) REFERENCES Accounts(account_id) ON DELETE CASCADE
);

INSERT INTO Customers (first_name, last_name, DOB, email, phone_number, address) VALUES
('Aarav', 'Sharma', '1990-05-15', 'aarav.sharma@email.com', '9876543210', 'Mumbai'),
('Priya', 'Kumar', '1985-08-20', 'priya.kumar@email.com', '9876543211', 'Delhi'),
('Rahul', 'Verma', '1992-03-10', 'rahul.verma@email.com', '9876543212', 'Pune'),
('Sneha', 'Mehta', '1995-12-01', 'sneha.mehta@email.com', '9876543213', 'Mumbai'),
('Anil', 'Reddy', '1980-07-07', 'anil.reddy@email.com', '9876543214', 'Hyderabad'),
('Pooja', 'Nair', '1993-11-25', 'pooja.nair@email.com', '9876543215', 'Chennai'),
('Karan', 'Singh', '1989-06-30', 'karan.singh@email.com', '9876543216', 'Delhi'),
('Meena', 'Patel', '1991-09-18', 'meena.patel@email.com', '9876543217', 'Ahmedabad'),
('Rohit', 'Desai', '1994-02-28', 'rohit.desai@email.com', '9876543218', 'Surat'),
('Divya', 'Joshi', '1996-04-12', 'divya.joshi@email.com', '9876543219', 'Mumbai');


INSERT INTO Accounts (customer_id, account_type, balance) VALUES
(1, 'savings', 2500.00),
(2, 'current', 1200.00),
(3, 'savings', 0.00),
(4, 'zero_balance', 0.00),
(5, 'current', 850.00),
(6, 'savings', 5000.00),
(7, 'current', 25000.00),
(8, 'savings', 100.00),
(9, 'savings', 0.00),
(10, 'current', 1050.00);


INSERT INTO Transactions (account_id, transaction_type, amount, transaction_date) VALUES
(1, 'deposit', 500.00, '2025-04-01 10:00:00'),
(1, 'withdrawal', 100.00, '2025-04-02 11:00:00'),
(2, 'deposit', 300.00, '2025-04-01 09:00:00'),
(2, 'transfer', 200.00, '2025-04-03 12:00:00'),
(3, 'deposit', 1000.00, '2025-04-04 14:30:00'),
(4, 'withdrawal', 500.00, '2025-04-04 15:00:00'),
(5, 'deposit', 700.00, '2025-04-05 08:45:00'),
(6, 'deposit', 600.00, '2025-04-05 09:30:00'),
(7, 'withdrawal', 1200.00, '2025-04-05 10:15:00'),
(10, 'deposit', 150.00, '2025-04-05 11:00:00');

select * from customers;
select * from transactions;
select * from accounts;

-- 1. Write a SQL query to retrieve the name, account type and email of all customers.
SELECT c.first_name, c.last_name, a.account_type, c.email
FROM Customers c
JOIN Accounts a ON c.customer_id = a.customer_id;

-- 2. Write a SQL query to list all transaction corresponding customer.
SELECT t.transaction_id, t.transaction_type, t.amount, t.transaction_date, c.first_name, c.last_name
FROM Transactions t
JOIN Accounts a ON t.account_id = a.account_id
JOIN Customers c ON a.customer_id = c.customer_id;

-- 3. Write a SQL query to increase the balance of a specific account by a certain amount.
UPDATE Accounts
SET balance = balance + 500
WHERE account_id = 1;

-- 4. Write a SQL query to Combine first and last names of customers as a full_name.
select concat(first_name,' ',last_name) as full_name
from customers where customer_id = 1;

-- 5. Write a SQL query to remove accounts with a balance of zero where the account type is savings.
DELETE FROM Accounts
WHERE balance = 0 AND account_type = 'savings';

-- 6. Write a SQL query to Find customers living in a specific city.
SELECT * FROM Customers
WHERE address LIKE '%Mumbai%';

-- 7. Write a SQL query to Get the account balance for a specific account.
SELECT balance
FROM Accounts
WHERE account_id = 2;

-- 8. Write a SQL query to List all current accounts with a balance greater than $1,000.
SELECT *
FROM Accounts
WHERE account_type = 'current' AND balance > 1000;

-- 9. Write a SQL query to Retrieve all transactions for a specific account.
SELECT *
FROM Transactions
WHERE account_id = 1;

-- 10. Write a SQL query to Calculate the interest accrued on savings accounts based on a given interest rate.
SELECT
    account_id,
    customer_id,
    balance,
    balance * 0.04 AS interest_accrued
FROM Accounts
WHERE account_type = 'savings';

-- 11. Write a SQL query to Identify accounts where the balance is less than a specified overdraft limit.
SELECT *
FROM Accounts
WHERE account_type = 'current' AND balance < 500;

-- 12. Write a SQL query to Find customers not living in a specific city.
SELECT *
FROM Customers
WHERE address NOT LIKE '%Mumbai%';

-- Task 2
-- 1. Write a SQL query to Find the average account balance for all customers.
SELECT AVG(balance) AS average_balance
FROM Accounts;

-- 2. Write a SQL query to Retrieve the top 10 highest account balances.
SELECT *
FROM Accounts
ORDER BY balance DESC
LIMIT 10;
select * from transactions;
-- 3. Write a SQL query to Calculate Total Deposits for All Customers on a specific date (e.g., '2025-04-05').
-- 3. Calculate Total Deposits for All Customers on 23rd September 2025
SELECT SUM(amount) AS total_deposits
FROM Transactions
WHERE transaction_type = 'deposit'
  AND DATE(transaction_date) = '2025-04-05';


-- 4. Write a SQL query to Find the Oldest and Newest Customers based on DOB.
SELECT *
FROM Customers
ORDER BY DOB ASC
LIMIT 1;  -- Oldest customer

-- To find the newest (youngest) customer:
SELECT *
FROM Customers
ORDER BY DOB DESC
LIMIT 1;

-- 5. Write a SQL query to Retrieve transaction details along with the account type.
SELECT t.*, a.account_type
FROM Transactions t
JOIN Accounts a ON t.account_id = a.account_id;

-- 6. Write a SQL query to Get a list of customers along with their account details.
SELECT c.customer_id, c.first_name, c.last_name, a.account_id, a.account_type, a.balance
FROM Customers c
JOIN Accounts a ON c.customer_id = a.customer_id;

-- 7. Write a SQL query to Retrieve transaction details along with customer information for a specific account (e.g., account_id = 'A101').
SELECT t.*, c.first_name, c.last_name, c.email
FROM Transactions t
JOIN Accounts a ON t.account_id = a.account_id
JOIN Customers c ON a.customer_id = c.customer_id;

-- 8. Write a SQL query to Identify customers who have more than one account.
SELECT customer_id, COUNT(account_id) AS total_accounts
FROM Accounts
GROUP BY customer_id
HAVING COUNT(account_id) > 1;

-- 9. Write a SQL query to Calculate the difference in transaction amounts between deposits and withdrawals.
SELECT
    (SELECT SUM(amount) FROM Transactions WHERE transaction_type = 'deposit') -
    (SELECT SUM(amount) FROM Transactions WHERE transaction_type = 'withdrawal')
    AS difference_between_deposits_and_withdrawals;

-- 10. Write a SQL query to Calculate the average daily balance for each account over a specified period (e.g., 2025-04-01 to 2025-04-05).
-- Assuming balance is updated daily (simplified for exercise purposes):
SELECT
    account_id,
    AVG(balance) AS avg_daily_balance
FROM Accounts
WHERE account_id IN (
    SELECT account_id
    FROM Transactions
    WHERE transaction_date BETWEEN '2025-04-01' AND '2025-04-05'
)
GROUP BY account_id;

-- 10. Write a SQL query to Calculate the average daily balance for each account over a specified period (e.g., 2025-04-01 to 2025-04-05).
-- Assuming balance is updated daily (simplified for exercise purposes):
SELECT
    account_id,
    AVG(balance) AS avg_daily_balance
FROM Accounts
WHERE account_id IN (
    SELECT account_id
    FROM Transactions
    WHERE transaction_date BETWEEN '2025-04-01' AND '2025-04-05'
)
GROUP BY account_id;

-- 11. Calculate the total balance for each account type.
SELECT account_type, SUM(balance) AS total_balance
FROM Accounts
GROUP BY account_type;

-- 12. Identify accounts with the highest number of transactions order by descending order.
SELECT account_id, COUNT(transaction_id) AS transaction_count
FROM Transactions
GROUP BY account_id
ORDER BY transaction_count DESC;

-- 13. List customers with high aggregate account balances, along with their account types (e.g., balances over 10000).
SELECT c.customer_id, c.first_name, c.last_name, a.account_type, SUM(a.balance) AS total_balance
FROM Customers c
JOIN Accounts a ON c.customer_id = a.customer_id
GROUP BY c.customer_id, a.account_type
HAVING SUM(a.balance) > 10000;

-- 14. Identify and list duplicate transactions based on amount, date, and account
SELECT amount, DATE(transaction_date) AS txn_date, account_id, COUNT(*) AS duplicate_count
FROM Transactions
GROUP BY amount, DATE(transaction_date), account_id
HAVING COUNT(*) > 1;


-- Task 4
-- 1. Retrieve the customer(s) with the highest account balance.
SELECT c.*
FROM Customers c
JOIN Accounts a ON c.customer_id = a.customer_id
WHERE a.balance = (SELECT MAX(balance) FROM Accounts);

-- 2. Calculate the average account balance for customers who have more than one account.
SELECT AVG(balance) AS avg_balance
FROM Accounts
WHERE customer_id IN (
    SELECT customer_id
    FROM Accounts
    GROUP BY customer_id
    HAVING COUNT(account_id) > 1
);

-- 3. Retrieve accounts with transactions whose amounts exceed the average transaction amount.
SELECT *
FROM Transactions
WHERE amount > (SELECT AVG(amount) FROM Transactions);

-- 4. Identify customers who have no recorded transactions.
SELECT DISTINCT c.*
FROM Customers c
WHERE c.customer_id NOT IN (
    SELECT a.customer_id
    FROM Accounts a
    JOIN Transactions t ON a.account_id = t.account_id
);
-- 5. Calculate the total balance of accounts with no recorded transactions.
SELECT SUM(balance) AS total_balance_no_txns
FROM Accounts
WHERE account_id NOT IN (
    SELECT DISTINCT account_id FROM Transactions
);

-- 6. Retrieve transactions for accounts with the lowest balance.
SELECT *
FROM Transactions
WHERE account_id IN (
    SELECT account_id
    FROM Accounts
    WHERE balance = (SELECT MIN(balance) FROM Accounts)
);

-- 7. Identify customers who have accounts of multiple types.
SELECT customer_id
FROM Accounts
GROUP BY customer_id
HAVING COUNT(DISTINCT account_type) > 1;

-- 8. Calculate the percentage of each account type out of the total number of accounts.
SELECT
  account_type,
  COUNT(*) * 100.0 / (SELECT COUNT(*) FROM Accounts) AS percentage
FROM Accounts
GROUP BY account_type;

-- 9. Retrieve all transactions for a customer with a given customer_id (e.g., 101).
SELECT t.*
FROM Transactions t
JOIN Accounts a ON t.account_id = a.account_id
WHERE a.customer_id = 101;

-- 10. Calculate the total balance for each account type, using a subquery inside SELECT.
SELECT
  account_type,
  (SELECT SUM(balance) FROM Accounts a2 WHERE a2.account_type = a1.account_type) AS total_balance
FROM Accounts a1
GROUP BY account_type;


select * from accounts;
